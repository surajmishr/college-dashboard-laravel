<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Registration</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                @if ($errors->any())
                                <div class="alert alert-warning">
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li style="color:red">{{ $error}}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                                <div class="auth-form">
                                    <h4 class="text-center mb-4">Register your account</h4>
                                    <form action="{{route('registerSave')}}" method="post">
                                        @csrf
                                        <div class="form-group">
                                            <label><strong>Plan</strong></label>
                                            {{-- silver, gold, platinum --}}
                                            <select name="plan" class="form-control">
                                                <option value="" disabled {{ old('plan') == '' ? 'selected' : '' }}>select plan</option>
                                                <option value="silver" {{ old('plan') == 'silver' ? 'selected' : '' }}>silver</option>
                                                <option value="gold" {{ old('plan') == 'gold' ? 'selected' : '' }}>gold</option>
                                                <option value="platinum" {{ old('plan') == 'platinum' ? 'selected' : '' }}>platinum</option>
                                            </select>
                                            
                                        </div>
                                      
                                        <div class="form-group">
                                            <label><strong>Name</strong></label>
                                            <input type="text" class="form-control" name="name" placeholder="Enter your full name" value="{{ old('name') }}">
                                        </div>
                                        <div class="form-group">
                                            <label><strong>Email</strong></label>
                                            <input type="email" class="form-control" name="email" placeholder="Enter your email id" value="{{ old('email') }}">
                                        </div>
                                        <div class="form-group">
                                            <label><strong>Address</strong></label>
                                            <textarea class="form-control" name="address" cols="30" rows="5" placeholder="Enter your address">{{ old('address') }}</textarea>
                                        </div>

                                        <div class="form-group">
                                            <label><strong>Password</strong></label>
                                            <input class="form-control" type="password" name="password" placeholder="Enter your password">
                                        </div>
                                        
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Register</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/dlabnav-init.js"></script>

</body>

</html>