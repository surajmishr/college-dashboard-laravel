
        
        @include('template.list-form-layouts.header')
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
             
                
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="nav nav-pills mb-3">
                            <li class="nav-item"><a href="#list-view" data-toggle="tab" class="nav-link btn-primary mr-1 show active">List View</a></li>
                            <li class="nav-item"><a href="#grid-view" data-toggle="tab" class="nav-link btn-primary">Grid View</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-12">
                        <div class="row tab-content">
                            <div id="list-view" class="tab-pane fade active show col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title">All Professors  </h4>
                                        <a href="add-leads" class="btn btn-primary">+ Add new</a>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table id="example3" class="display" style="min-width: 845px">
                                                <thead>
                                                    <tr>
                                                        <th>All</th>
                                                        <th>Name</th>
                                                        <th>Location</th>
                                                        <th>Updated On</th>
                                                        <th>Shedule Date</th>
                                                        <th>Project</th>
                                                        <th>Mobile</th>
                                                        <th>Sales  Executive</th>
                                                        <th>Visit Done</th>
                                                        <th>Action</th>
                                                        <th>Enq.Form</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                      @foreach($leads as $lead_all)
                                                    <tr>
                                                        <td><img class="rounded-circle" width="35" src="images/profile/small/pic1.jpg" alt=""></td>
                                                        <td>{{$lead_all->user_name}}</td>
                                                        <td>Architect</td>
                                                        <td>Male</td>
                                                        <td>M.COM., P.H.D.</td>
                                                        <td><a href="javascript:void(0);"><strong>123 456 7890</strong></a></td>
                                                        <td><a href="javascript:void(0);"><strong>info@example.com</strong></a></td>
                                                        <td>2011/04/25</td>
                                                        <td><input type="button" data-toggle="modal" class="btn btn-info btn-xs" name="visit_done" value="Visit done" onclick="done_sitevisit('','','15428')"></td>
                                                        <td>


<form role="form" method="POST" id="updateTeamLeader" style="float: left;">
  <select title="Assign Lead" style="padding:1px;height:20px;border:none; width:67px;margin:-3px 0px -20px 0px;background-color:pink;" class="select2" name="us_id" id="jkl" onchange="assign_leader('a','4474','3645','Sagar" anant',this.value,'admin','3')="">
  <option value="" class="option2">Assign</option><option value="3644">Aakash Divar</option><option value="3628">Abhishek Gupta</option><option value="3640">Ayan</option><option value="3637">Deepak Verma</option><option value="2">Divya</option><option value="3639">grow</option><option value="3643">Kunal Waghmare</option><option value="3636">Mahesh Kadam</option><option value="3635">Naina Tajane</option><option value="3633">Renuka Mane</option><option value="3634">Sandeep Morya</option><option value="3641">Shubham Vishwakarma</option><option value="3642">Tarun Singh</option><option class="option2" value="delete">Disable </option></select>
<input type="hidden" name="status" value="a">
<input type="hidden" name="lead_id" value="4474">
<input type="hidden" name="loginID" value="3645">
<input type="hidden" name="name" value="Sagar Anant"> 
<input type="hidden" name="role" value="Admin">
  </form>
  <form role="form" method="POST" id="updateTeamLeader" style="float: left;">
  <select title="Assign Lead" style="padding:1px;height:20px;border:none; width:67px;margin:-3px 0px -20px 0px;background-color:#8bc34a91;" class="select2" name="us_id2" id="jkl2" onchange="assign_leader2('a','4482','3645','Sagar" anant',this.value,'admin','1')="">
  <option value="" class="option2">Share</option><option value="3644">Aakash Divar</option><option value="3628">Abhishek Gupta</option><option value="3640">Ayan</option><option value="3637">Deepak Verma</option><option value="2">Divya</option><option value="3639">grow</option><option value="3643">Kunal Waghmare</option><option value="3636">Mahesh Kadam</option><option value="3635">Naina Tajane</option><option value="3633">Renuka Mane</option><option value="3634">Sandeep Morya</option><option value="3641">Shubham Vishwakarma</option><option value="3642">Tarun Singh</option></select>
<input type="hidden" name="status" value="a">
<input type="hidden" name="lead_id" value="4482">
<input type="hidden" name="loginID" value="3645">
<input type="hidden" name="name" value="Sagar Anant"> 
<input type="hidden" name="role" value="Admin">
  </form>
                                                          <a class="tooltip-toggle btn btn-success btn-xs" data-toggle="tooltip" data-placement="top" title="Preview" href="javascript:void(0)" onclick="view('4474','3','other')" style="float: left;"><i class="fa fa-eye"></i></a>                                                        </td>
                                                        <td>Contact Form</td>                                               
                                                    </tr>
                                                      @endforeach
                                           

                                                 </td>

                                                      
                                                  
                                                  
                                                   
                                                   
                                                   
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="grid-view" class="tab-pane fade col-lg-12">
                                <div class="row">
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic2.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Alexander</h3>
                                                    <p class="text-muted">M.COM., P.H.D.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic3.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Elizabeth</h3>
                                                    <p class="text-muted">B.COM., M.COM.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic4.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Amelia</h3>
                                                    <p class="text-muted">M.COM., P.H.D.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic5.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Charlotte</h3>
                                                    <p class="text-muted">B.COM., M.COM.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic6.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Isabella</h3>
                                                    <p class="text-muted">B.A, B.C.A</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic7.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Sebastian</h3>
                                                    <p class="text-muted">M.COM., P.H.D.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic8.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Olivia</h3>
                                                    <p class="text-muted">B.COM., M.COM.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic9.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Emma</h3>
                                                    <p class="text-muted">B.A, B.C.A</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Female</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                        <div class="card card-profile">
                                            <div class="card-header justify-content-end pb-0">
                                                <div class="dropdown">
                                                    <button class="btn btn-link" type="button" data-toggle="dropdown">
                                                        <span class="dropdown-dots fs--1"></span>
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right border py-0">
                                                        <div class="py-2">
                                                            <a class="dropdown-item" href="javascript:void(0);">Edit</a>
                                                            <a class="dropdown-item text-danger" href="javascript:void(0);">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pt-2">
                                                <div class="text-center">
                                                    <div class="profile-photo">
                                                        <img src="images/profile/small/pic10.jpg" width="100" class="img-fluid rounded-circle" alt="">
                                                    </div>
                                                    <h3 class="mt-4 mb-1">Jackson</h3>
                                                    <p class="text-muted">M.COM., P.H.D.</p>
                                                    <ul class="list-group mb-3 list-group-flush">
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Gender :</span><strong>Male</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Phone No. :</span><strong>+01 123 456 7890</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Email:</span><strong>info@example.com</strong></li>
                                                        <li class="list-group-item px-0 d-flex justify-content-between">
                                                            <span class="mb-0">Address:</span><strong>#8901 Marmora Road</strong></li>
                                                    </ul>
                                                    <a class="btn btn-outline-primary btn-rounded mt-3 px-4" href="professor-profile.html">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


@include('template.list-form-layouts.footer')