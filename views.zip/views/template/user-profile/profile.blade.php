@include('template.list-form-layouts.header')

<!--**********************************
            Sidebar end
        ***********************************-->

<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        {{-- @if ($userData)
        <h1>{{ $userData->name }}</h1>
        <p>Email: {{ $userData->email }}</p>
        <p>Address: {{ $userData->address }}</p>
        <!-- Add other user details here -->
    @else
        <p>User not found.</p>
    @endif --}}

        <div class="card">
            <div class="card-body">
                <div class="pt-3">
                    <div class="settings-form">
                        <h4 class="text-primary">Account Setting</h4>
                        <form>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>Client Id</label>
                                    <input type="text" name="client_id" value="{{ $userData->client_id }}" class="form-control" readonly>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Active Plan</label>
                                    <input type="text" name="plan" value="{{ $userData->plan }}" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" value="{{ $userData->name }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" value="{{ $userData->email }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Phone No.</label>
                                <input type="tel" name="phone" value="{{ $userData->phone }}" class="form-control">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-12">
                                    <label>Address</label>
                                    <textarea name="address" class="form-control" cols="30" rows="5">{{ $userData->address }}</textarea>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-danger" type="submit">Cancel</button>
                                <button class="btn btn-success" type="submit">Update</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->


<!--**********************************
            Footer start
        ***********************************-->

@include('template.list-form-layouts.footer')
